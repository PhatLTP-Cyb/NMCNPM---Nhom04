# Task Manager – Tiến hóa kiến trúc (Bài tập tuần 7)

Ứng dụng quản lý công việc với 4 chức năng cố định: **tạo task, xem danh sách, đổi trạng thái (chưa xong/hoàn thành), xóa task**.
Cùng một codebase được nâng cấp qua 4 phiên bản, mỗi phiên bản có một git tag.

| Tag | Phiên bản | Kiến trúc | Lưu trữ |
|---|---|---|---|
| `v1` | Chạy trên một máy | Backend tối giản + trang web | `tasks.json` |
| `v2` | Nhiều client | Client–Server, polling 2 giây | `tasks.json` (trên server) |
| `v3` | Kanban + SQLite | Client–Server + N-Layer + MVC phía client | `tasks.db` (SQLite) |
| `v4` | Mất server | V3 + kênh P2P bằng WebRTC DataChannel | SQLite (chế độ server) + bản sao localStorage (chế độ P2P) |

## Công nghệ
- Node.js ≥ 18 (đã thử với Node 22), Express 4
- better-sqlite3 (V3, V4)
- HTML/CSS/JavaScript thuần (ES modules), WebRTC API của trình duyệt (V4)

## Cài đặt và chạy
```bash
npm install
npm run migrate   # (V3 trở đi) chuyển tasks.json -> tasks.db, chạy lại nhiều lần không bị trùng
npm start         # http://localhost:3000
```
Server lắng nghe trên `0.0.0.0:3000` (từ V2), terminal in ra địa chỉ LAN để máy khác truy cập.

Xem lại từng phiên bản:
```bash
git checkout v1   # hoặc v2, v3, v4
npm install
npm start
git checkout main # quay lại bản mới nhất
```

## Cấu trúc thư mục (bản cuối)
```
server.js                        # composition root: chọn repository, lắp các tầng
src/presentation/taskRoutes.js   # REST API (Presentation phía server)
src/business/taskService.js      # nghiệp vụ (Business Logic)
src/data/jsonTaskRepository.js   # Data Access: JSON
src/data/sqliteTaskRepository.js # Data Access: SQLite
scripts/migrate-json-to-sqlite.js
public/index.html, public/css/style.css
public/js/api.js                 # gọi REST API
public/js/model.js               # Model (2 chế độ: server / p2p)
public/js/view.js                # View Kanban
public/js/controller.js          # Controller + bảng kết nối P2P
public/js/p2p.js                 # WebRTC DataChannel, signaling thủ công
public/js/localStore.js          # bản sao task cục bộ của mỗi peer
tests/e2e-v1..v4.js              # kịch bản kiểm thử tự động (Playwright, tùy chọn)
docs/KIEN-TRUC.md                # sơ đồ V2, V3, luồng V4 (Mermaid)
docs/NHAT-KY.md                  # nhật ký quyết định + prompt + kết quả test
```

## Cách thử từng phiên bản
| Phiên bản | Thao tác | Đạt khi |
|---|---|---|
| V1 | Tạo 2 task, tick 1 task, Ctrl+C rồi `npm start` lại, F5 | 2 task và trạng thái còn nguyên |
| V2 | Mở Chrome và Edge (hoặc cửa sổ ẩn danh). A thêm task, chờ 2 giây ở B; B tick, chờ ở A | Hai bên thấy cùng dữ liệu |
| V3 | `npm run migrate`, `npm start`, mở Kanban; tạo, chuyển cột, xóa; restart | Task cũ từ V2 còn, chức năng cũ hoạt động |
| V4 | Hai trình duyệt mở app, làm 3 bước trong "Kết nối P2P", **tắt server (Ctrl+C), không F5**; A tạo task, B chuyển cột | Hai peer vẫn nhận cập nhật của nhau |

Kiểm thử tự động (tùy chọn): `npm i -D playwright && npx playwright install chromium`, rồi `node tests/e2e-v4.js` (mỗi file ứng với tag cùng số).

## Giới hạn đã biết
- V2: polling 2 giây nên có độ trễ; không có realtime.
- V4: chỉ 2 peer; không giải quyết xung đột khi hai người sửa cùng một task (gộp đơn giản theo `updatedAt`); xóa trong lúc chưa kết nối có thể bị "hồi sinh" khi gộp snapshot; thay đổi trong chế độ P2P **chưa** được ghi ngược về server khi server sống lại; tải lại trang khi server đã tắt sẽ không mở được app.
