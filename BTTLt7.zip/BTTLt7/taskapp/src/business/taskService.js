// BUSINESS LOGIC LAYER - quy tắc nghiệp vụ của task
// Không biết dữ liệu nằm ở JSON hay SQLite, không biết giao diện là danh sách hay Kanban.
class ValidationError extends Error {}
class NotFoundError extends Error {}

class TaskService {
  constructor(repository) {
    this.repo = repository; // được "tiêm" từ server.js (dependency injection)
  }

  async listTasks() {
    return this.repo.findAll();
  }

  async createTask(title) {
    const clean = (title || '').trim();
    if (!clean) throw new ValidationError('Tên task không được rỗng');
    if (clean.length > 200) throw new ValidationError('Tên task tối đa 200 ký tự');
    const task = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      title: clean,
      done: false,
      createdAt: new Date().toISOString(),
    };
    return this.repo.insert(task);
  }

  async setDone(id, done) {
    const task = await this.repo.findById(id);
    if (!task) throw new NotFoundError('Không tìm thấy task');
    return this.repo.update({ ...task, done: Boolean(done) });
  }

  async deleteTask(id) {
    await this.repo.remove(id);
  }
}

module.exports = { TaskService, ValidationError, NotFoundError };
