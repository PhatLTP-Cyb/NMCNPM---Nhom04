// PRESENTATION LAYER (phía server) - REST API, chỉ chuyển HTTP <-> lời gọi service
const express = require('express');
const { ValidationError, NotFoundError } = require('../business/taskService');

function createTaskRoutes(service) {
  const router = express.Router();

  const handle = fn => async (req, res) => {
    try {
      await fn(req, res);
    } catch (err) {
      if (err instanceof ValidationError) return res.status(400).json({ error: err.message });
      if (err instanceof NotFoundError) return res.status(404).json({ error: err.message });
      console.error(err);
      res.status(500).json({ error: 'Lỗi server' });
    }
  };

  router.get('/', handle(async (req, res) => res.json(await service.listTasks())));
  router.post('/', handle(async (req, res) => res.status(201).json(await service.createTask(req.body.title))));
  router.patch('/:id', handle(async (req, res) => res.json(await service.setDone(req.params.id, req.body.done))));
  router.delete('/:id', handle(async (req, res) => {
    await service.deleteTask(req.params.id);
    res.status(204).end();
  }));

  return router;
}

module.exports = createTaskRoutes;
