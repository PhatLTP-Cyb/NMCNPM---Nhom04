// DATA ACCESS LAYER - lưu task vào SQLite (cùng interface với JsonTaskRepository)
const Database = require('better-sqlite3');

class SqliteTaskRepository {
  constructor(dbPath) {
    this.db = new Database(dbPath);
    this.db.exec(`CREATE TABLE IF NOT EXISTS tasks (
      id        TEXT PRIMARY KEY,
      title     TEXT NOT NULL,
      done      INTEGER NOT NULL DEFAULT 0,
      createdAt TEXT NOT NULL
    )`);
  }

  // SQLite lưu boolean dạng 0/1 -> đổi lại cho đúng kiểu mà tầng trên mong đợi
  #toTask(row) {
    return row ? { id: row.id, title: row.title, done: row.done === 1, createdAt: row.createdAt } : null;
  }

  async findAll() {
    return this.db.prepare('SELECT * FROM tasks ORDER BY createdAt').all().map(r => this.#toTask(r));
  }

  async findById(id) {
    return this.#toTask(this.db.prepare('SELECT * FROM tasks WHERE id = ?').get(id));
  }

  async insert(task) {
    this.db.prepare('INSERT INTO tasks (id, title, done, createdAt) VALUES (?, ?, ?, ?)')
      .run(task.id, task.title, task.done ? 1 : 0, task.createdAt);
    return task;
  }

  async update(task) {
    this.db.prepare('UPDATE tasks SET title = ?, done = ? WHERE id = ?')
      .run(task.title, task.done ? 1 : 0, task.id);
    return task;
  }

  async remove(id) {
    this.db.prepare('DELETE FROM tasks WHERE id = ?').run(id);
  }
}

module.exports = SqliteTaskRepository;
