// DATA ACCESS LAYER - lưu task vào file JSON
// Mọi repository đều có cùng các hàm: findAll, findById, insert, update, remove
const fs = require('fs');

class JsonTaskRepository {
  constructor(filePath) {
    this.filePath = filePath;
  }

  #read() {
    if (!fs.existsSync(this.filePath)) return [];
    return JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
  }

  #write(tasks) {
    const tmp = this.filePath + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(tasks, null, 2));
    fs.renameSync(tmp, this.filePath);
  }

  async findAll() {
    return this.#read();
  }

  async findById(id) {
    return this.#read().find(t => t.id === id) || null;
  }

  async insert(task) {
    const tasks = this.#read();
    tasks.push(task);
    this.#write(tasks);
    return task;
  }

  async update(task) {
    const tasks = this.#read().map(t => (t.id === task.id ? task : t));
    this.#write(tasks);
    return task;
  }

  async remove(id) {
    this.#write(this.#read().filter(t => t.id !== id));
  }
}

module.exports = JsonTaskRepository;
