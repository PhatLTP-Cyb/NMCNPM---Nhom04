const { chromium } = require('playwright');
const { spawn } = require('child_process');
const APP = require('path').join(__dirname, '..');
const start = (cmd='server.js') => new Promise(r => { const p = spawn('node', [cmd], { cwd: APP }); p.stdout.on('data', d => { process.stdout.write('[srv] '+d); r(p); }); p.stderr.on('data', d => process.stdout.write('[err] '+d)); });
(async () => {
  let s = await start();
  const b = await chromium.launch(); const pg = await b.newPage();
  await pg.goto('http://localhost:3000');
  for (const t of ['Viết báo cáo', 'Họp nhóm']) { await pg.fill('#title', t); await pg.click('form button'); await pg.waitForTimeout(300); }
  await pg.locator('li input[type=checkbox]').first().check(); await pg.waitForTimeout(300);
  s.kill(); await new Promise(r => setTimeout(r, 500));
  s = await start();
  await pg.reload(); await pg.waitForTimeout(500);
  console.log(await pg.locator('li').evaluateAll(ls => ls.map(l => l.className + ':' + l.textContent.trim().replace(/\s+/g,' '))));
  await pg.screenshot({ path: '' + APP + '/tests/v1.png' });
  await b.close(); s.kill();
})();
