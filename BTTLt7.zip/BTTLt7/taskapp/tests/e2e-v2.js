const { chromium } = require('playwright');
const { spawn } = require('child_process');
const APP = require('path').join(__dirname, '..');
const start = () => new Promise(r => { const p = spawn('node', ['server.js'], { cwd: APP }); p.stdout.on('data', d => { process.stdout.write('[srv] '+d); r(p); }); });
const rows = pg => pg.locator('li').evaluateAll(ls => ls.map(l => (l.className||'todo') + ':' + l.querySelector('span').textContent));
(async () => {
  const s = await start();
  const b = await chromium.launch();
  const A = await (await b.newContext()).newPage(), B = await (await b.newContext()).newPage();
  await A.goto('http://localhost:3000'); await B.goto('http://localhost:3000');
  await A.fill('#title', 'Task từ A'); await A.click('form button');
  await B.waitForTimeout(2500); console.log('B thấy:', await rows(B));
  await B.locator('li', { hasText: 'Task từ A' }).locator('input').last().check();
  await A.waitForTimeout(2500); console.log('A thấy:', await rows(A));
  s.kill(); await A.waitForTimeout(2500); console.log('A status khi tắt server:', await A.textContent('#status'));
  await b.close();
})();
