const { chromium } = require('playwright');
const { spawn } = require('child_process');
const APP = require('path').join(__dirname, '..');
const start = () => new Promise(r => { const p = spawn('node', ['server.js'], { cwd: APP }); p.stdout.on('data', d => r(p)); });
const cols = async pg => ({ todo: await pg.locator('#col-todo .card-title').allTextContents(), done: await pg.locator('#col-done .card-title').allTextContents() });
(async () => {
  const s = await start();
  const b = await chromium.launch({ args: process.argv[2] ? [process.argv[2]] : [] });
  const A = await (await b.newContext({ viewport: { width: 1000, height: 900 } })).newPage();
  const B = await (await b.newContext({ viewport: { width: 1000, height: 900 } })).newPage();
  for (const p of [A, B]) { await p.goto('http://localhost:3000'); await p.click('#p2p-panel summary'); }
  await A.click('#btn-offer'); await A.waitForFunction(() => document.getElementById('my-code').value.length > 50);
  await B.fill('#their-code', await A.inputValue('#my-code')); await B.click('#btn-answer');
  await B.waitForFunction(() => document.getElementById('my-code').value.length > 50);
  await A.fill('#their-code', await B.inputValue('#my-code')); await A.click('#btn-connect');
  await A.waitForFunction(() => document.getElementById('p2p-state').textContent === 'Đã kết nối', null, { timeout: 10000 });
  console.log('Kết nối P2P OK. B state:', await B.textContent('#p2p-state'));
  s.kill(); await new Promise(r => setTimeout(r, 2500)); console.log('Đã tắt server');
  try { await (await fetch('http://localhost:3000/api/tasks')).json(); console.log('!! server vẫn sống'); } catch { console.log('Xác nhận server không phản hồi'); }
  await A.fill('#title', 'Task P2P từ A'); await A.click('#form button'); await B.waitForTimeout(800);
  console.log('B thấy:', await cols(B));
  await B.locator('.card', { hasText: 'Task P2P từ A' }).locator('.move').click(); await A.waitForTimeout(800);
  console.log('A thấy:', await cols(A));
  await A.locator('.card', { hasText: 'Task P2P từ A' }).locator('.del').click(); await B.waitForTimeout(800);
  console.log('B sau khi A xóa:', await cols(B));
  console.log('Status A:', await A.textContent('#status'));
  await A.screenshot({ path: '' + APP + '/tests/v4.png', fullPage: true });
  await b.close();
})().catch(e => { console.error(e.message); process.exit(1); });
