const { chromium } = require('playwright');
const { spawn } = require('child_process');
const APP = require('path').join(__dirname, '..');
const start = () => new Promise(r => { const p = spawn('node', ['server.js'], { cwd: APP }); p.stdout.on('data', d => r(p)); p.stderr.on('data', d => process.stdout.write('[err] '+d)); });
const cols = async pg => ({ todo: await pg.locator('#col-todo .card-title').allTextContents(), done: await pg.locator('#col-done .card-title').allTextContents() });
(async () => {
  let s = await start();
  const b = await chromium.launch(); const pg = await b.newPage({ viewport: { width: 1000, height: 650 } });
  await pg.goto('http://localhost:3000'); await pg.waitForTimeout(800);
  console.log('Sau migrate:', await cols(pg));
  await pg.fill('#title', 'Task mới ở V3'); await pg.click('#form button'); await pg.waitForTimeout(500);
  await pg.locator('.card', { hasText: 'Task mới ở V3' }).locator('.move').click(); await pg.waitForTimeout(500);
  await pg.locator('#col-todo .card', { hasText: 'Họp nhóm' }).locator('.del').click(); await pg.waitForTimeout(500);
  s.kill(); await new Promise(r => setTimeout(r, 400)); s = await start();
  await pg.reload(); await pg.waitForTimeout(800);
  console.log('Sau restart:', await cols(pg));
  await pg.screenshot({ path: '' + APP + '/tests/v3.png' });
  await b.close(); s.kill();
})();
