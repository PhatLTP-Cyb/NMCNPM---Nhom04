// V3 - Composition root: lắp ráp các tầng Presentation -> Business -> Data Access
const express = require('express');
const path = require('path');
const os = require('os');
const createTaskRoutes = require('./src/presentation/taskRoutes');
const { TaskService } = require('./src/business/taskService');
const SqliteTaskRepository = require('./src/data/sqliteTaskRepository');

// Chọn nguồn lưu trữ ở ĐÚNG MỘT chỗ này
const repository = new SqliteTaskRepository(path.join(__dirname, 'tasks.db'));
const service = new TaskService(repository);

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/tasks', createTaskRoutes(service));

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server đang chạy tại http://localhost:${PORT}`);
  for (const nets of Object.values(os.networkInterfaces())) {
    for (const n of nets) {
      if (n.family === 'IPv4' && !n.internal) console.log(`  Máy khác trong LAN: http://${n.address}:${PORT}`);
    }
  }
});
