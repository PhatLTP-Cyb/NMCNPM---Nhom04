# Sơ đồ kiến trúc

## V2 – Client–Server
```mermaid
flowchart LR
  A["Trình duyệt A<br/>index.html + script<br/>polling 2s"] -- "HTTP REST /api/tasks" --> S
  B["Trình duyệt B<br/>index.html + script<br/>polling 2s"] -- "HTTP REST /api/tasks" --> S
  S["Server Node/Express<br/>server.js<br/>0.0.0.0:3000"] -- "đọc/ghi (atomic)" --> F[("tasks.json")]
```
Dữ liệu chỉ nằm ở server. Tắt server thì client không đọc/ghi được (server là điểm lỗi duy nhất).

## V3 – Client–Server + N-Layer + MVC
```mermaid
flowchart TB
  subgraph Client["Trình duyệt (MVC)"]
    V["View<br/>view.js · index.html · style.css<br/>Kanban 2 cột"]
    C["Controller<br/>controller.js"]
    M["Model<br/>model.js"]
    API["api.js"]
    V <--> C
    C --> M
    M --> API
  end
  subgraph Server["Server Node/Express (N-Layer)"]
    P["Presentation<br/>taskRoutes.js"]
    BL["Business Logic<br/>taskService.js"]
    DA["Data Access<br/>sqliteTaskRepository.js<br/>(jsonTaskRepository.js)"]
    P --> BL --> DA
  end
  API -- "HTTP REST" --> P
  DA --> DB[("tasks.db")]
  MIG["scripts/migrate-json-to-sqlite.js"] -- "đọc" --> J[("tasks.json")]
  MIG -- "INSERT OR IGNORE" --> DB
```

## V4 – Luồng kết nối P2P
```mermaid
sequenceDiagram
  participant A as Peer A (trình duyệt)
  participant U as Người dùng (copy/paste)
  participant B as Peer B (trình duyệt)
  participant S as Server (V3)
  A->>S: Tải trang, đọc task (chế độ Server)
  B->>S: Tải trang, đọc task (chế độ Server)
  A->>A: 1. createOffer + chờ ICE xong
  A->>U: Mã lời mời (SDP base64)
  U->>B: Dán mã lời mời
  B->>B: 2. setRemoteDescription + createAnswer
  B->>U: Mã trả lời
  U->>A: Dán mã trả lời
  A->>B: 3. ICE + DTLS: DataChannel "tasks" mở (trực tiếp)
  A-->>B: snapshot (gộp bản sao)
  B-->>A: snapshot
  Note over S: Tắt server (Ctrl+C)
  A-->>B: {type: create, task}
  B-->>A: {type: setDone, id, done}
  Note over A,B: Mỗi peer lưu bản sao trong localStorage
```
