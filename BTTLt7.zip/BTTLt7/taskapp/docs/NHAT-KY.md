# Nhật ký quyết định kiến trúc

| Version | NFR mới | Quyết định thiết kế | File/thành phần đổi | Kết quả test |
|---|---|---|---|---|
| V1 | Dữ liệu còn sau khi khởi động lại (persistence) trên 1 máy | Express phục vụ trang tĩnh + REST API; đọc/ghi toàn bộ `tasks.json` mỗi request; HTML + JS viết chung 1 file | `server.js`, `public/index.html` | Tạo 2 task, tick 1, restart → còn đủ 2 task, trạng thái đúng |
| V2 | Chia sẻ trạng thái tập trung giữa nhiều client | Client–Server: listen `0.0.0.0`, polling 2 giây, ghi file atomic (tmp + rename), hiển thị trạng thái kết nối | `server.js`, `public/index.html` | A tạo → B thấy sau ≤ 2 giây; B tick → A thấy; tắt server → client báo mất kết nối |
| V3 | Modifiability: thay UI và persistence mà nghiệp vụ giữ nguyên | Tách N-Layer (routes / service / repository), dependency injection ở `server.js`; MVC phía client; repository SQLite cùng interface; script migrate idempotent | Đổi UI: `view.js`, `index.html`, `style.css`. Đổi DB: `sqliteTaskRepository.js` (mới), `migrate-json-to-sqlite.js` (mới), `server.js` (2 dòng), `package.json` | Migrate 2 lần không trùng; task V2 hiện trên Kanban; tạo/chuyển cột/xóa; restart vẫn còn |
| V4 | Availability khi mất server; giao tiếp ngang hàng | Giữ chế độ Server của V3; thêm chế độ P2P: WebRTC DataChannel, signaling thủ công bằng copy/paste, `iceServers: []`; bản sao localStorage; gửi thao tác (create/setDone/delete) + snapshot khi kết nối | `p2p.js` (mới), `localStore.js` (mới), `model.js`, `controller.js`, `index.html`, `style.css` | Kết nối A–B, tắt server; A tạo → B nhận; B chuyển cột → A nhận; A xóa → B nhận |

## Ràng buộc mới và hạn chế của thiết kế cũ (viết trước mỗi phiên bản)
- **Trước V2** – Ràng buộc: hai thiết bị phải thấy cập nhật của nhau. Hạn chế V1: server chỉ nghe `localhost`, client chỉ tải dữ liệu khi chính nó thao tác.
- **Trước V3** – Ràng buộc: đổi UI sang Kanban và JSON sang SQLite mà không mất dữ liệu. Hạn chế V2: route vừa xử lý HTTP, vừa kiểm tra dữ liệu, vừa đọc/ghi file; HTML trộn với logic gọi API.
- **Trước V4** – Ràng buộc: server không truy cập được, 2 máy vẫn cộng tác. Hạn chế V3: mọi thao tác phải qua server – server là điểm lỗi duy nhất.

## Prompt chính đã dùng
- V1: "Tạo ứng dụng quản lý công việc Node.js + Express: tạo, xem, đánh dấu hoàn thành, xóa task. Lưu vào tasks.json ở backend, giao diện 1 trang HTML đơn giản. Không cần đăng nhập."
- V2: "Sửa code hiện có (không tạo project mới) để 2 trình duyệt trên 2 máy dùng chung dữ liệu: server nghe 0.0.0.0, client polling 2 giây, ghi file an toàn, hiển thị khi mất kết nối server."
- V3a: "Chỉ ra chỗ code đang trộn giao diện, nghiệp vụ và truy cập dữ liệu. Tách thành presentation/business/data với repository interface, frontend tách model/view/controller. Không đổi hành vi."
- V3b: "Đổi giao diện danh sách sang Kanban 2 cột Chưa hoàn thành / Hoàn thành. Chỉ sửa View."
- V3c: "Thêm SqliteTaskRepository cùng interface với JsonTaskRepository, script migrate tasks.json sang tasks.db chạy lại không trùng, đổi server.js sang SQLite."
- V4: "Giữ chế độ server của V3, thêm chế độ P2P bằng WebRTC DataChannel với signaling thủ công copy/paste, không dùng server chuyển tiếp. Mỗi peer lưu bản sao localStorage, gửi thao tác trực tiếp."

## Lỗi phát sinh
- `EADDRINUSE: address already in use :3000` khi chạy lại test trong lúc server cũ vẫn chạy → tắt tiến trình cũ trước khi `npm start`.
- (Ghi thêm lỗi nhóm gặp khi chạy trên máy mình.)
