// Gọi REST API của server (phía client)
export const TaskApi = {
  async list() {
    const res = await fetch('/api/tasks');
    if (!res.ok) throw new Error('Không đọc được danh sách');
    return res.json();
  },
  async create(title) {
    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    });
    if (!res.ok) throw new Error((await res.json()).error);
    return res.json();
  },
  async setDone(id, done) {
    await fetch('/api/tasks/' + id, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ done }),
    });
  },
  async remove(id) {
    await fetch('/api/tasks/' + id, { method: 'DELETE' });
  },
};
