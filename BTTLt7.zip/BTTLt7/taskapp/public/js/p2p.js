// V4 - Kênh P2P bằng WebRTC DataChannel, signaling THỦ CÔNG (copy/paste mã)
// Không dùng server nào để trao đổi mã kết nối hay chuyển tiếp cập nhật.
const encode = desc => btoa(JSON.stringify(desc));
const decode = code => JSON.parse(atob(code.trim()));

export class PeerLink {
  constructor() {
    // iceServers rỗng: chỉ dùng địa chỉ trong mạng LAN / cùng máy, không cần STUN/TURN
    this.pc = new RTCPeerConnection({ iceServers: [] });
    this.handlers = { open: [], close: [], message: [] };
    this.pc.ondatachannel = e => this.#setup(e.channel); // phía B nhận kênh do A tạo
  }

  on(event, fn) {
    this.handlers[event].push(fn);
  }

  #emit(event, data) {
    this.handlers[event].forEach(fn => fn(data));
  }

  #setup(channel) {
    this.channel = channel;
    channel.onopen = () => this.#emit('open');
    channel.onclose = () => this.#emit('close');
    channel.onmessage = e => this.#emit('message', JSON.parse(e.data));
  }

  // Chờ thu thập xong ICE candidate để mã copy đi đã chứa đủ địa chỉ (không cần trickle ICE)
  #waitIce() {
    if (this.pc.iceGatheringState === 'complete') return Promise.resolve();
    return new Promise(resolve => {
      const timer = setTimeout(resolve, 3000);
      this.pc.addEventListener('icegatheringstatechange', () => {
        if (this.pc.iceGatheringState === 'complete') { clearTimeout(timer); resolve(); }
      });
    });
  }

  // Bước 1 (máy A): tạo lời mời
  async createOffer() {
    this.#setup(this.pc.createDataChannel('tasks'));
    await this.pc.setLocalDescription(await this.pc.createOffer());
    await this.#waitIce();
    return encode(this.pc.localDescription);
  }

  // Bước 2 (máy B): nhận lời mời, tạo trả lời
  async acceptOffer(code) {
    await this.pc.setRemoteDescription(decode(code));
    await this.pc.setLocalDescription(await this.pc.createAnswer());
    await this.#waitIce();
    return encode(this.pc.localDescription);
  }

  // Bước 3 (máy A): nhận trả lời -> kết nối trực tiếp được thiết lập
  async acceptAnswer(code) {
    await this.pc.setRemoteDescription(decode(code));
  }

  get isOpen() {
    return this.channel && this.channel.readyState === 'open';
  }

  send(message) {
    if (this.isOpen) this.channel.send(JSON.stringify(message));
  }
}
