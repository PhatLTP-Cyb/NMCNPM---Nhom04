// CONTROLLER - nối Model với View, xử lý polling và bảng kết nối P2P
import { TaskModel } from './model.js';
import { TaskView } from './view.js';
import { PeerLink } from './p2p.js';

const model = new TaskModel();
const view = new TaskView();

model.onChange(tasks => view.render(tasks));

const safe = fn => async (...args) => {
  try {
    await fn(...args);
    if (model.mode === 'server') {
      view.setStatus('Chế độ Server · cập nhật lúc ' + new Date().toLocaleTimeString(), true);
    }
  } catch (err) {
    view.setStatus('Mất kết nối server - hãy chuyển sang chế độ P2P', false);
  }
};

view.bindCreate(safe(title => model.create(title)));
view.bindToggle(safe((id, done) => model.setDone(id, done)));
view.bindDelete(safe(id => model.remove(id)));

// Polling chỉ chạy ở chế độ server
const poll = safe(() => model.refresh());
poll();
setInterval(() => { if (model.mode === 'server') poll(); }, 2000);

// ---------- Bảng kết nối P2P (signaling thủ công) ----------
const $ = id => document.getElementById(id);
let peer = null;

function newPeer() {
  peer = new PeerLink();
  peer.on('open', () => {
    model.enterP2P(peer);
    view.setStatus('Chế độ P2P · đã kết nối trực tiếp với peer (có thể tắt server)', true);
    $('p2p-state').textContent = 'Đã kết nối';
  });
  peer.on('close', () => {
    model.leaveP2P();
    view.setStatus('Kết nối P2P đã đóng - quay lại chế độ Server', false);
    $('p2p-state').textContent = 'Chưa kết nối';
  });
  return peer;
}

$('btn-offer').onclick = async () => {
  $('my-code').value = 'Đang tạo...';
  $('my-code').value = await newPeer().createOffer();
};

$('btn-answer').onclick = async () => {
  $('my-code').value = 'Đang tạo...';
  $('my-code').value = await newPeer().acceptOffer($('their-code').value);
};

$('btn-connect').onclick = async () => {
  await peer.acceptAnswer($('their-code').value);
  $('p2p-state').textContent = 'Đang kết nối...';
};

$('btn-copy').onclick = () => {
  $('my-code').select();
  navigator.clipboard?.writeText($('my-code').value).catch(() => document.execCommand('copy'));
};
