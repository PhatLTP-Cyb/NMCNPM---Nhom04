// MODEL - giữ danh sách task. Hai chế độ:
//   'server': đọc/ghi qua REST API (như V3, chế độ thông thường)
//   'p2p'   : đọc/ghi bản sao cục bộ + gửi thao tác trực tiếp cho peer qua WebRTC
import { TaskApi } from './api.js';
import { LocalTaskStore } from './localStore.js';

const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

export class TaskModel {
  constructor() {
    this.tasks = [];
    this.listeners = [];
    this.mode = 'server';
    this.local = new LocalTaskStore();
    this.peer = null;
  }

  onChange(fn) {
    this.listeners.push(fn);
  }

  #emit() {
    this.listeners.forEach(fn => fn(this.tasks));
  }

  // ---------- chuyển chế độ ----------
  enterP2P(peer) {
    this.mode = 'p2p';
    this.peer = peer;
    // Bản sao cục bộ = dữ liệu đang thấy từ server + những gì còn lưu cục bộ trước đó
    this.tasks = this.local.merge(this.local.load(), this.tasks);
    this.local.save(this.tasks);
    peer.on('message', msg => this.#receive(msg));
    peer.send({ type: 'snapshot', tasks: this.tasks }); // trao đổi trạng thái ban đầu
    this.#emit();
  }

  leaveP2P() {
    this.mode = 'server';
    this.peer = null;
  }

  #receive(msg) {
    if (msg.type === 'snapshot') {
      this.tasks = this.local.merge(this.tasks, msg.tasks);
    } else {
      this.tasks = this.local.apply(this.tasks, msg);
    }
    this.local.save(this.tasks);
    this.#emit();
  }

  #applyLocalAndSend(op) {
    this.tasks = this.local.apply(this.tasks, op);
    this.local.save(this.tasks);
    this.peer.send(op);
    this.#emit();
  }

  // ---------- 4 chức năng ----------
  async refresh() {
    if (this.mode === 'p2p') return this.#emit();
    this.tasks = await TaskApi.list();
    this.#emit();
  }

  async create(title) {
    if (this.mode === 'p2p') {
      const clean = (title || '').trim();
      if (!clean) return;
      const now = new Date().toISOString();
      return this.#applyLocalAndSend({
        type: 'create',
        task: { id: newId(), title: clean, done: false, createdAt: now, updatedAt: now },
      });
    }
    await TaskApi.create(title);
    await this.refresh();
  }

  async setDone(id, done) {
    if (this.mode === 'p2p') {
      return this.#applyLocalAndSend({ type: 'setDone', id, done, at: new Date().toISOString() });
    }
    await TaskApi.setDone(id, done);
    await this.refresh();
  }

  async remove(id) {
    if (this.mode === 'p2p') return this.#applyLocalAndSend({ type: 'delete', id });
    await TaskApi.remove(id);
    await this.refresh();
  }
}
