// VIEW - chỉ lo hiển thị và bắt sự kiện người dùng (giao diện KANBAN 2 cột)
export class TaskView {
  constructor() {
    this.form = document.getElementById('form');
    this.input = document.getElementById('title');
    this.todoCol = document.getElementById('col-todo');
    this.doneCol = document.getElementById('col-done');
    this.todoCount = document.getElementById('count-todo');
    this.doneCount = document.getElementById('count-done');
    this.status = document.getElementById('status');
  }

  bindCreate(handler) {
    this.form.onsubmit = e => {
      e.preventDefault();
      handler(this.input.value);
      this.input.value = '';
    };
  }

  bindToggle(handler) { this.onToggle = handler; }
  bindDelete(handler) { this.onDelete = handler; }

  #card(t) {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `<div class="card-title"></div>
      <div class="card-actions">
        <button class="move">${t.done ? '← Chưa xong' : 'Hoàn thành →'}</button>
        <button class="del">Xóa</button>
      </div>`;
    card.querySelector('.card-title').textContent = t.title;
    card.querySelector('.move').onclick = () => this.onToggle(t.id, !t.done);
    card.querySelector('.del').onclick = () => this.onDelete(t.id);
    return card;
  }

  render(tasks) {
    const todo = tasks.filter(t => !t.done);
    const done = tasks.filter(t => t.done);
    this.todoCol.replaceChildren(...todo.map(t => this.#card(t)));
    this.doneCol.replaceChildren(...done.map(t => this.#card(t)));
    this.todoCount.textContent = todo.length;
    this.doneCount.textContent = done.length;
  }

  setStatus(text, ok) {
    this.status.textContent = text;
    this.status.className = ok ? '' : 'offline';
  }
}
