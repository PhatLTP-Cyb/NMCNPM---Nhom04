// V4 - Bản sao task cục bộ của mỗi peer (lưu trong localStorage của trình duyệt)
const KEY = 'p2p-tasks';

export class LocalTaskStore {
  load() {
    try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; }
  }

  save(tasks) {
    try { localStorage.setItem(KEY, JSON.stringify(tasks)); } catch { /* bỏ qua */ }
  }

  // Áp dụng một thao tác (do chính mình tạo hoặc nhận từ peer)
  apply(tasks, op) {
    switch (op.type) {
      case 'create':
        return tasks.some(t => t.id === op.task.id) ? tasks : [...tasks, op.task];
      case 'setDone':
        return tasks.map(t => (t.id === op.id ? { ...t, done: op.done, updatedAt: op.at } : t));
      case 'delete':
        return tasks.filter(t => t.id !== op.id);
      default:
        return tasks;
    }
  }

  // Gộp ảnh chụp (snapshot) của peer khi vừa kết nối: hợp theo id,
  // trùng id thì giữ bản có updatedAt mới hơn (Last-Write-Wins đơn giản)
  merge(mine, theirs) {
    const byId = new Map(mine.map(t => [t.id, t]));
    for (const t of theirs) {
      const cur = byId.get(t.id);
      if (!cur || (t.updatedAt || '') > (cur.updatedAt || '')) byId.set(t.id, t);
    }
    return [...byId.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  }
}
