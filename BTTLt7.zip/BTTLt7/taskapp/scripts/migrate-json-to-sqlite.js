// Chuyển dữ liệu cũ từ tasks.json (V1, V2) sang tasks.db (V3)
// Chạy: npm run migrate   -- an toàn khi chạy lại nhiều lần (INSERT OR IGNORE theo id)
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const root = path.join(__dirname, '..');
const jsonPath = path.join(root, 'tasks.json');
const dbPath = path.join(root, 'tasks.db');

if (!fs.existsSync(jsonPath)) {
  console.log('Không có tasks.json, không cần chuyển dữ liệu.');
  process.exit(0);
}

const tasks = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
const db = new Database(dbPath);
db.exec(`CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, createdAt TEXT NOT NULL
)`);

const insert = db.prepare('INSERT OR IGNORE INTO tasks (id, title, done, createdAt) VALUES (?, ?, ?, ?)');
const migrateAll = db.transaction(list => {
  let added = 0;
  for (const t of list) {
    added += insert.run(t.id, t.title, t.done ? 1 : 0, t.createdAt || new Date().toISOString()).changes;
  }
  return added;
});

const added = migrateAll(tasks);
const total = db.prepare('SELECT COUNT(*) AS n FROM tasks').get().n;
console.log(`tasks.json có ${tasks.length} task -> thêm mới ${added}, tasks.db hiện có ${total} task.`);
db.close();
